const fetch = require('node-fetch');

exports.handler = async function(event, context) {
  try {
    // URL 파라미터 파싱
    const { json } = event.queryStringParameters || {};
    
    if (!json) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'JSON parameter is required' })
      };
    }
    
    // URL 디코딩
    const decodedJsonPath = decodeURIComponent(json);
    
    // Dropbox URL을 직접 다운로드 URL로 변환
    const directJsonUrl = decodedJsonPath
      .replace('www.dropbox.com', 'dl.dropboxusercontent.com')
      .replace('?dl=0', '?dl=1')
      .replace('&dl=0', '&dl=1');
    
    // JSON 데이터 가져오기
    const response = await fetch(directJsonUrl);
    const data = await response.json();
    
    if (!data || !data.models || data.models.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'No models found in JSON data' })
      };
    }
    
    const firstModel = data.models[0];
    const thumbnailUrl = firstModel.thumbnailUrl;
    
    // 모델 정보 추출
    const modelName = firstModel.name || 'Pre-operative 3D Model';
    const folderName = data.folderInfo?.name || '';
    const description = data.folderInfo?.description || '';
    
    // 폴더명만 사용 (LiverAiz3D 중복 제거)
    const title = folderName || 'LiverAiz3D';
    
    // description 무시하고 기본 설명 사용
    const fullDescription = `Pre-operative 3D Model for assisting the surgical planning`;
    
    // 썸네일 URL 처리
    let imageUrl = 'https://3dviewertest.netlify.app/img/logo-dark.png'; // 기본 이미지
    if (thumbnailUrl) {
      if (thumbnailUrl.includes("dropbox.com")) {
        imageUrl = thumbnailUrl
          .replace("www.dropbox.com", "dl.dropboxusercontent.com")
          .replace("?dl=0", "?dl=1")
          .replace("&dl=0", "&dl=1");
        
        if (!imageUrl.includes("dl=")) {
          imageUrl += (imageUrl.includes("?") ? "&" : "?") + "dl=1";
        }
      } else {
        imageUrl = thumbnailUrl;
      }
    }
    
    // HTML 페이지 생성
    const html = `
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} - Liver Viewer</title>
    
    <!-- 오픈그래프 메타 태그 -->
    <meta property="og:title" content="${title}">
    <meta property="og:description" content="${fullDescription}">
    <meta property="og:image" content="${imageUrl}">
    <meta property="og:url" content="${event.headers.referer || 'https://3dviewertest.netlify.app/'}">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Liver Viewer">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:type" content="image/png">
    <meta property="og:locale" content="ko_KR">
    <meta property="og:locale:alternate" content="en_US">
    
    <!-- Twitter Card 메타 태그 -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="${title}">
    <meta name="twitter:description" content="${fullDescription}">
    <meta name="twitter:image" content="${imageUrl}">
    <meta name="twitter:site" content="@liver_viewer">
    <meta name="twitter:image:alt" content="${modelName}">
    <meta name="twitter:creator" content="@liver_viewer">
    
    <!-- 추가 메타 태그 -->
    <meta name="description" content="${fullDescription}">
    <meta name="keywords" content="3D, model, viewer, liver, surgery, medical, ${modelName}">
    <meta name="author" content="Liver Viewer">
    
    <!-- 파비콘 -->
    <link rel="icon" type="image/svg+xml" href="/img/favicon.svg">
    <link rel="icon" type="image/png" href="/img/favicon-96x96.png">
    <link rel="apple-touch-icon" href="/img/web-app-manifest-192x192.png">
    <link rel="manifest" href="/img/site.webmanifest">
    
    <!-- Pretendard 폰트 -->
    <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
    
    <!-- 스타일시트 -->
    <link rel="stylesheet" href="style.css">
    
    <script>
        // 원래 페이지로 리다이렉트
        window.location.href = '/?json=${encodeURIComponent(json)}';
    </script>
</head>
<body>
    <div id="container"></div>
    <script type="module" src="/src/index.js"></script>
</body>
</html>`;
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html',
        'Cache-Control': 'no-cache'
      },
      body: html
    };
    
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
}; 