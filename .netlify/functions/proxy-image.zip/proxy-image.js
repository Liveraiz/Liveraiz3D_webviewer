exports.handler = async function(event, context) {
  console.log('=== Netlify Function proxy-image 호출됨 ===');
  
  // CORS 헤더 설정
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  };
  
  // OPTIONS 요청 처리 (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }
  
  try {
    const { url } = event.queryStringParameters || {};
    console.log('요청된 URL:', url);
    
    if (!url) {
      console.log('URL 파라미터가 없음');
      return { 
        statusCode: 400, 
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'URL parameter is required' }) 
      };
    }
    
    let directUrl = url;
    if (url.includes("dropbox.com")) {
      console.log('Dropbox URL 감지, 변환 중...');
      // Dropbox URL을 직접 다운로드 URL로 변환
      directUrl = url
        .replace("www.dropbox.com", "dl.dropboxusercontent.com")
        .replace("?dl=0", "?dl=1")
        .replace("&dl=0", "&dl=1");
      
      // uid 파라미터 제거
      if (directUrl.includes("&uid=")) {
        directUrl = directUrl.replace(/&uid=[^&]*/, '');
      }
      
      if (!directUrl.includes("dl=")) {
        directUrl += (directUrl.includes("?") ? "&" : "?") + "dl=1";
      }
      
      console.log('변환된 URL:', directUrl);
    }
    
    console.log('이미지 요청 중:', directUrl);
    
    const response = await fetch(directUrl);
    console.log('응답 상태:', response.status, response.statusText);
    
    if (!response.ok) {
      console.error('이미지 로드 실패:', response.status, response.statusText);
      return { 
        statusCode: response.status, 
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Failed to fetch image' }) 
      };
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const contentType = response.headers.get('content-type') || 'image/jpeg';
    
    console.log('이미지 프록시 성공:', contentType, buffer.length, 'bytes');
    
    // 카카오톡 호환성을 위한 추가 헤더
    const responseHeaders = {
      ...headers,
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      'Content-Length': buffer.length,
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'SAMEORIGIN'
    };
    
    // 카카오톡 크롤러 감지
    const userAgent = event.headers['user-agent'] || '';
    const isKakaoCrawler = userAgent.includes('KakaoTalk') || 
                           userAgent.includes('KakaoBot') || 
                           userAgent.includes('KakaoStory') ||
                           userAgent.includes('KakaoWebView');
    
    if (isKakaoCrawler) {
      console.log('카카오톡 크롤러 감지됨:', userAgent);
      responseHeaders['Cache-Control'] = 'no-cache, no-store, must-revalidate, max-age=0';
      responseHeaders['Pragma'] = 'no-cache';
      responseHeaders['Expires'] = '0';
      responseHeaders['Last-Modified'] = new Date().toUTCString();
      responseHeaders['ETag'] = `"kakao-${Date.now()}"`;
      
      // 카카오톡 전용 추가 헤더
      responseHeaders['X-Kakao-Cache'] = 'no';
      responseHeaders['X-Kakao-Timestamp'] = Date.now().toString();
    }
    
    return {
      statusCode: 200,
      headers: responseHeaders,
      body: buffer.toString('base64'),
      isBase64Encoded: true
    };
  } catch (error) {
    console.error('프록시 오류:', error);
    return { 
      statusCode: 500, 
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Internal server error', details: error.message }) 
    };
  }
}; 