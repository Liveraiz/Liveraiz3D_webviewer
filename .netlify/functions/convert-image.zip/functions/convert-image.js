const fetch = require('node-fetch');

exports.handler = async function(event, context) {
  try {
    const { url, width = 1200, height = 630 } = event.queryStringParameters || {};
    if (!url) {
      return { 
        statusCode: 400, 
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'URL parameter is required' }) 
      };
    }
    
    let directUrl = url;
    if (url.includes("dropbox.com")) {
      // Dropbox URL 변환
      directUrl = url
        .replace("www.dropbox.com", "dl.dropboxusercontent.com")
        .replace("?dl=0", "?dl=1")
        .replace("&dl=0", "&dl=1");
      
      if (directUrl.includes("&uid=")) {
        directUrl = directUrl.replace(/&uid=[^&]*/, '');
      }
      
      if (!directUrl.includes("dl=")) {
        directUrl += (directUrl.includes("?") ? "&" : "?") + "dl=1";
      }
    }
    
    console.log('이미지 변환 요청:', directUrl);
    
    const response = await fetch(directUrl);
    if (!response.ok) {
      console.error('이미지 로드 실패:', response.status);
      return { 
        statusCode: response.status, 
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Failed to fetch image' }) 
      };
    }
    
    const buffer = await response.buffer();
    const contentType = response.headers.get('content-type') || 'image/jpeg';
    
    // 이미지 변환 로직 (간단한 리사이즈)
    // 실제로는 sharp나 jimp 같은 라이브러리를 사용해야 함
    console.log('이미지 변환 성공:', contentType, buffer.length, 'bytes');
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=86400',
        'Content-Length': buffer.length
      },
      body: buffer.toString('base64'),
      isBase64Encoded: true
    };
  } catch (error) {
    console.error('이미지 변환 오류:', error);
    return { 
      statusCode: 500, 
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Internal server error' }) 
    };
  }
}; 