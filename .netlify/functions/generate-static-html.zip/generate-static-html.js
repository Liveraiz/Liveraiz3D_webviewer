const fs = require('fs').promises;
const path = require('path');

exports.handler = async function(event, context) {
  console.log('=== 정적 HTML 생성 함수 호출됨 ===');
  
  try {
    const { json, date, time, source } = event.queryStringParameters || {};
    console.log('URL 파라미터:', { json, date, time, source });
    
    if (!json) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'JSON 파라미터가 필요합니다.' })
      };
    }
    
    // Dropbox URL을 직접 다운로드 URL로 변환
    const directJsonUrl = json
      .replace('www.dropbox.com', 'dl.dropboxusercontent.com')
      .replace('?dl=0', '?dl=1')
      .replace('&dl=0', '&dl=1');
    
    console.log('변환된 JSON URL:', directJsonUrl);
    
    const response = await fetch(directJsonUrl);
    if (!response.ok) {
      throw new Error(`JSON 데이터 로드 실패: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('JSON 데이터 로드 성공:', data);
    
    if (!data || !data.models || data.models.length === 0) {
      throw new Error('모델 데이터가 없습니다.');
    }
    
    const firstModel = data.models[0];
    const folderName = data.folderInfo?.name || '';
    const modelName = firstModel.name || 'Pre-operative 3D Model';
    
    // 파일명 생성 (안전한 문자로 변환)
    const safeFileName = folderName.replace(/[^a-zA-Z0-9]/g, '_') || 'model';
    const fileName = `${safeFileName}.html`;
    
    // 썸네일 URL 처리
    let imageUrl = '';
    if (firstModel.thumbnailUrl) {
      let thumbnailUrl = firstModel.thumbnailUrl;
      if (thumbnailUrl.includes("dropbox.com")) {
        thumbnailUrl = thumbnailUrl
          .replace("www.dropbox.com", "dl.dropboxusercontent.com")
          .replace("?dl=0", "?dl=1")
          .replace("&dl=0", "&dl=1");
        
        if (thumbnailUrl.includes("&uid=")) {
          thumbnailUrl = thumbnailUrl.replace(/&uid=[^&]*/, '');
        }
        
        if (!thumbnailUrl.includes("dl=")) {
          thumbnailUrl += (thumbnailUrl.includes("?") ? "&" : "?") + "dl=1";
        }
        
        // Cloudinary fetch URL 사용
        imageUrl = `https://res.cloudinary.com/dmktvk7fw/image/fetch/w_1200,h_900,c_fill,f_auto,q_auto/${encodeURIComponent(thumbnailUrl)}`;
      } else {
        imageUrl = thumbnailUrl;
      }
    }
    
    // 제목과 설명 설정
    const title = folderName || 'LiverAiz3D';
    const description = `Pre-operative 3D Model for assisting the surgical planning`;
    
    // 소스 정보 추가
    const finalTitle = source === 'LiverAiz3D' ? `${title} - LiverAiz3D` : title;
    const finalDescription = source === 'LiverAiz3D' ? `${description} - LiverAiz3D` : description;
    
    // 날짜 정보 추가
    let dateInfo = '';
    if (date) {
      const formattedDate = new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
      dateInfo = ` (${formattedDate})`;
    }
    
    const fullDescription = `${finalDescription}${dateInfo}`;
    
    // HTML 템플릿 생성
    const html = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- 기본 오픈그래프 메타 태그 -->
  <meta property="og:title" content="${finalTitle}">
  <meta property="og:description" content="${fullDescription}">
  <meta property="og:image" content="${imageUrl}">
  <meta property="og:url" content="https://3dviewertest.netlify.app/share/${fileName}">
  <meta property="og:type" content="video.other">
  <meta property="og:image:secure_url" content="${imageUrl}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="900">
  <meta property="og:image:type" content="image/jpeg">
  <meta property="og:site_name" content="Liver Viewer">
  <meta property="og:locale" content="ko_KR">
  <meta property="og:locale:alternate" content="en_US">
  
  <!-- 3D 모델 전용 메타태그 -->
  <meta property="og:video:type" content="text/html">
  <meta property="og:video:width" content="1200">
  <meta property="og:video:height" content="900">
  
  <!-- 카카오톡 전용 메타태그 -->
  <meta property="og:determiner" content="the">
  <meta property="og:image:alt" content="${finalTitle}">
  <meta property="og:updated_time" content="${new Date().toISOString()}">
  
  <!-- Twitter Card 메타 태그 -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${finalTitle}">
  <meta name="twitter:description" content="${fullDescription}">
  <meta name="twitter:image" content="${imageUrl}">
  <meta name="twitter:site" content="@liver_viewer">
  <meta name="twitter:image:alt" content="${finalTitle}">
  <meta name="twitter:creator" content="@liver_viewer">
  
  <!-- 카카오톡 크롤러 최적화 -->
  <meta name="robots" content="index, follow">
  <meta name="googlebot" content="index, follow">
  <meta name="kakao" content="index, follow">
  
  <!-- 추가 메타 태그 -->
  <meta name="description" content="${fullDescription}">
  <meta name="keywords" content="3D, model, viewer, liver, surgery, medical">
  <meta name="author" content="Liver Viewer">
  
  <title>${finalTitle} - Liver Viewer</title>
  
  <!-- 파비콘 -->
  <link rel="icon" type="image/svg+xml" href="/favicon_light_b.svg">
  <link rel="apple-touch-icon" href="/web-app-manifest-192x192.png">
  <link rel="manifest" href="/site.webmanifest">
  
  <!-- Pretendard 폰트 -->
  <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
  
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Pretendard', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    .container {
      text-align: center;
      padding: 1.5rem;
      max-width: 100%;
      width: 100%;
    }
    
    .image {
      max-width: 100%;
      max-height: 250px;
      width: auto;
      height: auto;
      border-radius: 10px;
      margin-bottom: 1rem;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    }
    
    .title {
      margin: 0 0 0.5rem 0;
      font-size: clamp(1.2rem, 4vw, 1.5rem);
      font-weight: 600;
      line-height: 1.3;
      word-wrap: break-word;
    }
    
    .description {
      margin: 0;
      opacity: 0.9;
      font-size: clamp(0.9rem, 3vw, 1rem);
      line-height: 1.4;
      word-wrap: break-word;
    }
    
    .button {
      background: rgba(255,255,255,0.2);
      border: 1px solid rgba(255,255,255,0.3);
      color: white;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      cursor: pointer;
      font-family: inherit;
      text-decoration: none;
      display: inline-block;
      font-size: clamp(0.9rem, 3vw, 1rem);
      font-weight: 500;
      transition: all 0.2s ease;
      margin-top: 1.5rem;
    }
    
    .button:hover {
      background: rgba(255,255,255,0.3);
    }
    
    .countdown {
      margin-top: 1rem;
      font-size: 0.9rem;
      opacity: 0.8;
    }
  </style>
</head>
<body>
  <div class="container">
    <img src="${imageUrl}" alt="3D 모델 썸네일" class="image">
    <h1 class="title">${finalTitle}</h1>
    <p class="description">${fullDescription}</p>
    <a href="https://3dviewertest.netlify.app/?json=${encodeURIComponent(json)}&date=${date || ''}&time=${time || ''}&source=${source || ''}" class="button">Open 3D Viewer</a>
    <div class="countdown" id="countdown">3초 후 자동으로 3D 뷰어로 이동합니다...</div>
  </div>
  
  <script>
    // 3초 후 자동 리다이렉트
    let countdown = 3;
    const countdownElement = document.getElementById('countdown');
    
    const timer = setInterval(() => {
      countdown--;
      countdownElement.textContent = \`\${countdown}초 후 자동으로 3D 뷰어로 이동합니다...\`;
      
      if (countdown <= 0) {
        clearInterval(timer);
        window.location.href = "https://3dviewertest.netlify.app/?json=${encodeURIComponent(json)}&date=${date || ''}&time=${time || ''}&source=${source || ''}";
      }
    }, 1000);
  </script>
</body>
</html>`;
    
    // public/share 디렉토리에 파일 저장
    const shareDir = path.join(process.cwd(), 'public', 'share');
    const filePath = path.join(shareDir, fileName);
    
    try {
      await fs.mkdir(shareDir, { recursive: true });
      await fs.writeFile(filePath, html, 'utf8');
      console.log('정적 HTML 파일 생성 완료:', filePath);
    } catch (error) {
      console.error('파일 저장 실패:', error);
      throw error;
    }
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: true,
        fileName: fileName,
        url: `https://3dviewertest.netlify.app/share/${fileName}`,
        title: finalTitle,
        description: fullDescription,
        image: imageUrl
      })
    };
    
  } catch (error) {
    console.error('정적 HTML 생성 오류:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
}; 