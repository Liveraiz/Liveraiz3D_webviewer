const fetch = require('node-fetch');

exports.handler = async function(event, context) {
  try {
    const { modelUrl, modelName, thumbnailUrl } = event.queryStringParameters || {};
    
    // 기본 이미지 URL
    let finalThumbnailUrl = 'https://3dviewertest.netlify.app/img/logo-dark.png';
    
    if (thumbnailUrl) {
      try {
        // Dropbox URL을 직접 다운로드 URL로 변환
        let convertedUrl = thumbnailUrl;
        if (thumbnailUrl.includes("dropbox.com")) {
          convertedUrl = thumbnailUrl
            .replace("www.dropbox.com", "dl.dropboxusercontent.com")
            .replace("?dl=0", "?dl=1")
            .replace("&dl=0", "&dl=1");
          
          // uid 파라미터 제거
          if (convertedUrl.includes("&uid=")) {
            convertedUrl = convertedUrl.replace(/&uid=[^&]*/, '');
          }
          
          if (!convertedUrl.includes("dl=")) {
            convertedUrl += (convertedUrl.includes("?") ? "&" : "?") + "dl=1";
          }
        }
        
        // 이미지 접근 가능성 확인
        const response = await fetch(convertedUrl, { method: 'HEAD' });
        if (response.ok) {
          finalThumbnailUrl = convertedUrl;
          console.log('썸네일 이미지 접근 성공:', finalThumbnailUrl);
        } else {
          console.log('썸네일 이미지 접근 실패, 기본 이미지 사용');
        }
      } catch (error) {
        console.error('썸네일 처리 실패:', error);
      }
    }
    
    return {
      statusCode: 200,
      headers: { 
        'Content-Type': 'application/json', 
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=3600'
      },
      body: JSON.stringify({ 
        thumbnailUrl: finalThumbnailUrl, 
        modelName, 
        success: true, 
        message: 'Thumbnail generated successfully' 
      })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ 
        error: 'Internal server error',
        thumbnailUrl: 'https://3dviewertest.netlify.app/img/logo-dark.png'
      })
    };
  }
}; 