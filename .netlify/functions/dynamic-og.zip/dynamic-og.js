exports.handler = async function(event, context) {
  console.log('=== 동적 OG HTML 생성 함수 호출됨 ===');
  
  try {
    const { json, date, time, source } = event.queryStringParameters || {};
    console.log('URL 파라미터:', { json, date, time, source });
    
    // 기본 OG 데이터 (json 파라미터가 없으면 빈 값)
    let ogImage = "";
    let ogTitle = "";
    let ogDescription = "";
    let ogUrl = "https://3dviewertest.netlify.app/";
    
    // JSON 데이터에서 동적 정보 가져오기
    if (json && json.trim() !== '') {
      try {
        console.log('JSON 데이터 로드 시도:', json);
        
        // Dropbox URL을 직접 다운로드 URL로 변환
        const directJsonUrl = json
          .replace('www.dropbox.com', 'dl.dropboxusercontent.com')
          .replace('?dl=0', '?dl=1')
          .replace('&dl=0', '&dl=1');
        
        console.log('변환된 JSON URL:', directJsonUrl);
        
        const response = await fetch(directJsonUrl);
        if (response.ok) {
          const data = await response.json();
          console.log('JSON 데이터 로드 성공:', data);
          
          if (data && data.models && data.models.length > 0) {
            const firstModel = data.models[0];
            
            // 썸네일 URL 처리
            if (firstModel.thumbnailUrl) {
              let thumbnailUrl = firstModel.thumbnailUrl;
              if (thumbnailUrl.includes("dropbox.com")) {
                thumbnailUrl = thumbnailUrl
                  .replace("www.dropbox.com", "dl.dropboxusercontent.com")
                  .replace("?dl=0", "?dl=1")
                  .replace("&dl=0", "&dl=1");
                
                // uid 파라미터 제거
                if (thumbnailUrl.includes("&uid=")) {
                  thumbnailUrl = thumbnailUrl.replace(/&uid=[^&]*/, '');
                }
                
                if (!thumbnailUrl.includes("dl=")) {
                  thumbnailUrl += (thumbnailUrl.includes("?") ? "&" : "?") + "dl=1";
                }
                
                // 카카오톡 캐시 무효화를 위한 강화된 파라미터 추가
                const timestamp = Date.now();
                const randomId = Math.random().toString(36).substring(2, 15);
                thumbnailUrl += (thumbnailUrl.includes("?") ? "&" : "?") + `t=${timestamp}&kakao=1&v=${randomId}&cache=${Date.now()}`;
              }
              
              // 카카오톡 호환성을 위해 로컬 이미지 고정 사용
              ogImage = "https://3dviewertest.netlify.app/img/logo-dark.png";
              console.log('로컬 이미지 고정 사용:', ogImage);
            }
            
            // 제목과 설명 설정
            const modelName = firstModel.name || 'Pre-operative 3D Model';
            const folderName = data.folderInfo?.name || '';
            const description = data.folderInfo?.description || '';
            
            // 폴더명만 사용 (LiverAiz3D 중복 제거)
            ogTitle = folderName || 'LiverAiz3D';
            // description 무시하고 기본 설명 사용
            ogDescription = `Pre-operative 3D Model for assisting the surgical planning`;
            
            // 소스 정보 추가
            if (source === 'LiverAiz3D') {
              ogTitle += ' - LiverAiz3D';
              ogDescription += ' - LiverAiz3D';
            }
            
            // 날짜 정보 추가
            if (date) {
              const formattedDate = new Date(date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              });
              ogDescription += ` (${formattedDate})`;
            }
            
            ogUrl = `https://3dviewertest.netlify.app/?json=${encodeURIComponent(json)}&date=${date || ''}&time=${time || ''}&source=${source || ''}`;
          }
        } else {
          console.error('JSON 데이터 로드 실패:', response.status);
        }
      } catch (error) {
        console.error('JSON 처리 중 오류:', error);
      }
    }
    
    // 동적 HTML 생성
    const html = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- 기본 오픈그래프 메타 태그 -->
  <meta property="og:title" content="${ogTitle}">
  <meta property="og:description" content="${ogDescription}">
  <meta property="og:image" content="${ogImage}">
  <meta property="og:url" content="${ogUrl}">
  <meta property="og:type" content="video.other">
  <meta property="og:image:secure_url" content="${ogImage}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:type" content="image/png">
  <meta property="og:site_name" content="Liver Viewer">
  <meta property="og:locale" content="ko_KR">
  <meta property="og:locale:alternate" content="en_US">
  
  <!-- 3D 모델 전용 메타태그 (p3d.in 스타일) -->
  <meta property="og:video:type" content="text/html">
  <meta property="og:video:width" content="1200">
  <meta property="og:video:height" content="630">
  
  <!-- 카카오톡 전용 메타태그 -->
  <meta property="og:determiner" content="the">
  <meta property="og:image:alt" content="${ogTitle}">
  <meta property="og:updated_time" content="${new Date().toISOString()}">
  
  <!-- 카카오톡 추가 메타태그 -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${ogTitle}">
  <meta name="twitter:description" content="${ogDescription}">
  <meta name="twitter:image" content="${ogImage}">
  <meta name="twitter:site" content="@liver_viewer">
  <meta name="twitter:image:alt" content="${ogTitle}">
  <meta name="twitter:creator" content="@liver_viewer">
  
  <!-- 카카오톡 크롤러 최적화 -->
  <meta name="robots" content="index, follow">
  <meta name="googlebot" content="index, follow">
  <meta name="kakao" content="index, follow">
  
  <!-- 카카오톡 디버깅용 -->
  <meta name="format-detection" content="telephone=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  
  <!-- 카카오톡 추가 최적화 -->
  <meta name="application-name" content="Liver Viewer">
  <meta name="msapplication-TileColor" content="#667eea">
  <meta name="theme-color" content="#667eea">
  

  
  <!-- 추가 메타 태그 -->
  <meta name="description" content="${ogDescription}">
  <meta name="keywords" content="3D, model, viewer, liver, surgery, medical">
  <meta name="author" content="Liver Viewer">
  
  <title>${ogTitle} - Liver Viewer</title>
  
  <!-- 파비콘 -->
  <link rel="icon" type="image/svg+xml" href="/assets/favicon_light_b-CjibS8rY.svg">
  <link rel="apple-touch-icon" href="/assets/web-app-manifest-192x192-LAj0NdUT.png">
  <link rel="manifest" href="/assets/site-DGWt2i2_.webmanifest">
  
  <!-- Pretendard 폰트 -->
  <link rel="stylesheet" as="style" crossorigin href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
  
  <!-- 스타일시트 -->
  <link rel="stylesheet" href="/assets/index-7EKvFU1S.css">
</head>
<body>
  <div id="app">
    <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; font-family: 'Pretendard', sans-serif; padding: 1rem;">
      <div style="text-align: center; padding: 1.5rem; max-width: 100%; width: 100%;">
        <img src="https://3dviewertest.netlify.app/img/logo-dark.png" alt="3D 모델 썸네일" style="max-width: 100%; max-height: 250px; width: auto; height: auto; border-radius: 10px; margin-bottom: 1rem; box-shadow: 0 4px 20px rgba(0,0,0,0.3);">
        <h1 style="margin: 0 0 0.5rem 0; font-size: clamp(1.2rem, 4vw, 1.5rem); font-weight: 600; line-height: 1.3; word-wrap: break-word;">${ogTitle}</h1>
        <p style="margin: 0; opacity: 0.9; font-size: clamp(0.9rem, 3vw, 1rem); line-height: 1.4; word-wrap: break-word;">${ogDescription}</p>
        <div style="margin-top: 1.5rem;">
          <a href="${ogUrl}" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 0.75rem 1.5rem; border-radius: 8px; cursor: pointer; font-family: inherit; text-decoration: none; display: inline-block; font-size: clamp(0.9rem, 3vw, 1rem); font-weight: 500; transition: all 0.2s ease;">Open 3D Viewer</a>
        </div>
      </div>
    </div>
  </div>
  
  <!-- 카카오톡 크롤러 호환성을 위해 JavaScript 리다이렉트 임시 비활성화 -->
  <!--
  <script>
    function loadApp() {
      window.location.href = "${ogUrl}";
    }
    
    // 자동 리다이렉트 (선택사항)
    // setTimeout(() => {
    //   window.location.href = "${ogUrl}";
    // }, 3000);
  </script>
  -->
  
  <!-- 메인 애플리케이션 스크립트는 제거 (MIME 타입 문제 해결) -->
</body>
</html>`;
    
    console.log('동적 HTML 생성 완료');
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, max-age=3600',
        'Access-Control-Allow-Origin': '*'
      },
      body: html
    };
    
  } catch (error) {
    console.error('동적 OG HTML 생성 오류:', error);
    
    // 오류 시 기본 HTML 반환
    const fallbackHtml = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta property="og:title" content="Liver Viewer - 3D Model Viewer">
  <meta property="og:description" content="Pre-operative 3D Model for assisting the surgical planning">
  <meta property="og:image" content="https://3dviewertest.netlify.app/img/logo-dark.png">
  <meta property="og:url" content="https://3dviewertest.netlify.app/">
  <meta property="og:type" content="video.other">
  <title>Liver Viewer - 3D Model Viewer</title>
</head>
<body>
  <div style="display: flex; justify-content: center; align-items: center; height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; font-family: sans-serif;">
    <div style="text-align: center;">
      <h1>Liver Viewer</h1>
      <p>3D Model Viewer</p>
      <button onclick="window.location.href='https://3dviewertest.netlify.app/'">홈으로 이동</button>
    </div>
  </div>
</body>
</html>`;
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, max-age=3600'
      },
      body: fallbackHtml
    };
  }
}; 